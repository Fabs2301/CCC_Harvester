
public class Harvester {

	public static void main(String[] args) {

		int reihen = 10;
		int spalten = 10;
		int reihestart = 0;
		int spaltestart = 4;
		int[][] feld = new int[reihen][spalten];

		System.out.println("====================");
		for (int rh = 0; rh < reihen; rh++) {
			for (int sp = 0; sp < spalten; sp++) {
				System.out.print((sp + 1 + spalten * rh) + " ");
				feld[rh][sp] = sp + 1 + spalten * rh;
			}
			System.out.println();
		}
		System.out.println("====================");
		System.out.println();

		// logik
		
		
	if (reihestart!=1) {
		for (int i = reihestart-1; i <= reihen; i--) {
			if ((i % 2) == 1) {
				for (int as = 0; as < spalten; as++) {
					System.out.print((feld[i][as]) + " ");
				}
			} else if ((i % 2) == 0) {
				for (int sa = spalten+1; sa >= 0; sa--) {
					
				}
			}
		}
	}		
		if (spaltestart == 1) {
			for (int i = 0; i < reihen; i++) {
				if ((i % 2) == 0) {
					for (int as = 0; as < spalten; as++) {
						System.out.print((feld[i][as]) + " ");
					}
				} else if ((i % 2) == 1) {
					for (int sa = spalten - 1; sa >= 0; sa--) {
						System.out.print((feld[i][sa]) + " ");
					}
				}
			}
		}
		for (int i = reihestart-1; i < reihen; i++) {
			if ((i % 2) == 1) {
				for (int as = 0; as < spalten; as++) {
					System.out.print((feld[i][as]) + " ");
				}
			} else if ((i % 2) == 0) {
				for (int sa = spalten - 1; sa >= 0; sa--) {
					System.out.print((feld[i][sa]) + " ");
				}

			}

		}
	}
}
